//
//  Lab1App.swift
//  Lab1
//
//  Created by Tyler Fichiera on 1/23/23.
//

import SwiftUI

@main
struct Lab1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
